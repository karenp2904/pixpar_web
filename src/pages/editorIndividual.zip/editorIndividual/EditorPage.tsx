import React, { useState } from "react";

import EditorCanvas from "../../components/editor/EditorImages";
import EditorControls from "../../components/editor/EditorControl";
import EditorSidebar from "../../components/editor/EditorSideBar";
import ImageSelector from "../../components/editor/extra/ImageSelector";
import "./EditorPage.css";

const EditorPage: React.FC = () => {
  const [selectedImage, setSelectedImage] = useState<string>("");
  const [filter, setFilter] = useState<string>("none");

  // 🎚️ Ajustes de sliders
  const [adjustments, setAdjustments] = useState({
    brillo: 100,
    contraste: 100,
    saturacion: 100,
    intensidad: 100
  });

  return (
    <div className="editor-page">
   
      

      {/* 🔹 Main */}
      <main className="editor-main">
        {/* Barra lateral izquierda */}
        <aside className="editor-sidebar">
          <EditorSidebar activeTool={filter} setActiveTool={setFilter} />
        </aside>

        {/* Canvas central */}
        <section className="editor-content">
          <div className="editor-canvas-container">
            {selectedImage ? (
              <EditorCanvas
                selectedImage={selectedImage}
                filter={filter} activeTool={""}              />
            ) : (
              <ImageSelector onSelect={setSelectedImage} />
            )}
          </div>

          {/* Barra inferior */}
          <div className="editor-bottom-bar">
            
           

          </div>
        </section>

        {/* Controles de ajustes */}
        <aside className="editor-controls">
          <EditorControls
            selectedImage={selectedImage}
            filter={filter}
            setFilter={setFilter}
            adjustments={adjustments}
            setAdjustments={setAdjustments}
          />
        </aside>
      </main>
    </div>
  );
};

export default EditorPage;
