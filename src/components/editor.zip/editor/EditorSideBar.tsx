import React from 'react';
import { Icon } from '@iconify/react';
import { Tooltip } from '@heroui/react';
import "./Style/editorSideBar.css"

interface EditorSidebarProps {
  activeTool: string;
  setActiveTool: (tool: string) => void;
}

const tools = [
  { id: 'crop', icon: 'lucide:crop', label: 'Recortar' },
  { id: 'text', icon: 'lucide:type', label: 'Texto' },
  { id: 'rotate', icon: 'lucide:rotate-ccw', label: 'Rotar' }, 
];


const EditorSidebar: React.FC<EditorSidebarProps> = ({ activeTool, setActiveTool }) => {
  return (
   <div className="editor-sidebar h-full">
      {tools.map((tool) => (
        <Tooltip 
          key={tool.id}
          content={tool.label}
          placement="right"
        >
          <button
            className={`editor-sidebar-item w-12 h-12 rounded-md flex items-center justify-center my-1 ${
              activeTool === tool.id ? 'active' : ''
            }`}
            onClick={() => setActiveTool(tool.id)}
          >
            <Icon 
              icon={tool.icon} 
              className={`text-xl ${activeTool === tool.id ? 'text-primary' : 'text-gray-400'}`} 
            />
          </button>
        </Tooltip>
      ))}
    </div>
  );
};

export default EditorSidebar;