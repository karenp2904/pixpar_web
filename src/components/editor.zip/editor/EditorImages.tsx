import React, { useState } from "react";
import { motion } from "framer-motion";
import "./Style/editorCanvas.css";
import BrushTool from "./tools/BrushTool";
import CropTool from "./tools/CropTool";
import ShapeTool from "./tools/ShapeTool";
import TextTool from "./tools/TextTool";

// Herramientas individuales


interface EditorCanvasProps {
  selectedImage: string;
  filter: string;
  activeTool: string; // 🔹 agregado
}

const EditorCanvas: React.FC<EditorCanvasProps> = ({
  selectedImage,
  filter,
  activeTool,
}) => {
  const [isDrawing, setIsDrawing] = useState(false);


  const filterClassMap: Record<string, string> = {
    none: "",
    contrast: "contrast-125",
    brightness: "brightness-125",
    saturation: "saturate-150",
    blur: "blur-sm",
    grayscale: "grayscale",
    blue: "hue-rotate-180 saturate-200",
    black: "brightness-0",
    sepia: "sepia",
    warm: "brightness-110 saturate-150 hue-rotate-15",
    cool: "brightness-110 saturate-125 hue-rotate-180",
    dream: "brightness-125 saturate-125 blur-[1px]",
    noir: "contrast-200 grayscale",
    pop: "contrast-150 saturate-200",
    retro: "sepia hue-rotate-90",
    pastel: "brightness-110 saturate-75",
    shadow: "contrast-125 brightness-75",
  };

  return (
    <div className="editor-canvas-container flex-1 flex items-center justify-center bg-content1 p-6">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.3 }}
        className="editor-canvas border border-divider rounded-md overflow-hidden relative flex items-center justify-center"
      >
        {selectedImage ? (
          <img
            src={selectedImage}
            alt="Imagen en edición"
            className={`w-full h-full object-contain max-w-3xl max-h-[70vh] ${
              filterClassMap[filter] || ""
            }`}
          />


        ) : (
          <p className="text-gray-400">Selecciona una imagen para comenzar</p>
        )}

        {/* 🔹 Render dinámico de herramientas */}
        {activeTool === "crop" && <CropTool />}
        {activeTool === "brush" && <BrushTool isDrawing={isDrawing} setIsDrawing={setIsDrawing} />}
        {activeTool === "text" && <TextTool />}
        {activeTool === "shape" && <ShapeTool />}
      </motion.div>
    </div>
  );
};

export default EditorCanvas;
