import React from "react";
import { Slider } from "@heroui/react";
import "../Style/editorControl.css";

interface AdjustmentSlidersProps {
  adjustments: {
    brillo: number;
    contraste: number;
    saturacion: number;
    intensidad: number;
  };
  setAdjustments: (adj: any) => void;
}

const sliderLabels: Record<string, string> = {
  brillo: "Brillo",
  contraste: "Contraste",
  saturacion: "Saturación",
  intensidad: "Intensidad",
};

const sliderColors: Record<string, string> = {
  brillo: "#FFD700",
  contraste: "#FF1493", 
  saturacion: "#8A2BE2",
  intensidad: "#00CED1",
};

const AdjustSliders: React.FC<AdjustmentSlidersProps> = ({
  adjustments,
  setAdjustments,
}) => {
  return (
    <div className="editor-sliders" style={{ backgroundColor: '#1a1a1a', padding: '20px', borderRadius: '8px' }}>
      <h3 className="editor-sliders-title" style={{ color: 'white', marginBottom: '20px' }}>Filtros</h3>
      {Object.entries(adjustments).map(([key, value]) => (
        <div key={key} className="editor-slider-group" style={{ marginBottom: '20px' }}>
          {/* Etiqueta */}
          <div className="editor-slider-label" style={{ color: 'white', marginBottom: '8px' }}>
            <span>{sliderLabels[key] || key}</span>
          </div>

          {/* Slider */}
          <Slider
            aria-label={sliderLabels[key] || key}
            step={1}
            maxValue={100} 
            minValue={0}
            value={value}
            onChange={(val) =>
              setAdjustments({ ...adjustments, [key]: val as number })
            }
            color="primary"
            size="md"
            classNames={{
              base: "w-full mb-4",
              track: "h-2",
              filler: "h-2",
              thumb: "w-5 h-5 shadow-lg transition-transform hover:scale-110"
            }}
            style={{
              '--slider-color': sliderColors[key],
              '--slider-bg': sliderColors[key],
              background: `linear-gradient(90deg, ${sliderColors[key]} 0%, ${sliderColors[key]} 100%)`
            } as React.CSSProperties & { [key: string]: string }}
          />
        </div>
      ))}
    </div>
  );
};

export default AdjustSliders;