import React, { useState } from "react";
import "../Style/editorCanvas.css";

interface FilterThumbnailsProps {
  selectedImage: string;
  activeFilter: string;
  setActiveFilter: (filter: string) => void;
}

const filterOptions = [
  { id: "none", label: "Normal", class: "" },
  { id: "sepia", label: "Vintage", class: "sepia" },
  { id: "warm", label: "Cálido", class: "brightness-110 saturate-150 hue-rotate-15" },
  { id: "cool", label: "Frío", class: "brightness-110 saturate-125 hue-rotate-180" },
  { id: "dream", label: "Sueño", class: "brightness-125 saturate-125 blur-[1px]" },
  { id: "noir", label: "Noir", class: "contrast-200 grayscale" },
  { id: "pop", label: "Pop", class: "contrast-150 saturate-200" },
  { id: "retro", label: "Retro", class: "sepia hue-rotate-90" },
  { id: "pastel", label: "Pastel", class: "brightness-110 saturate-75" },
  { id: "shadow", label: "Sombras", class: "contrast-125 brightness-75" },
];

const ITEMS_PER_PAGE = 4;

const FilterThumbnails: React.FC<FilterThumbnailsProps> = ({
  selectedImage,
  activeFilter,
  setActiveFilter,
}) => {
  const [index, setIndex] = useState(0);

  // función para obtener 4 filtros en loop
  const getVisibleFilters = () => {
    const filters: typeof filterOptions = [];
    for (let i = 0; i < ITEMS_PER_PAGE; i++) {
      filters.push(filterOptions[(index + i) % filterOptions.length]);
    }
    return filters;
  };

  const next = () => setIndex((prev) => (prev + 1) % filterOptions.length);
  const prev = () =>
    setIndex(
      (prev) =>
        (prev - 1 + filterOptions.length) % filterOptions.length
    );

  return (
    <div className="filter-thumbnails">
      <h3 className="filter-title">Filtros</h3>

      <div className="filter-carousel-wrapper">
        {/* Flecha izquierda */}
        <button className="carousel-arrow left" onClick={prev}>
          ◀
        </button>

        {/* Carrusel siempre con 4 */}
        <div className="filter-carousel">
          {getVisibleFilters().map((f) => (
            <button
              key={f.id}
              className={`filter-thumb ${activeFilter === f.id ? "active" : ""}`}
              onClick={() => setActiveFilter(f.id)}
            >
              {selectedImage ? (
                <img
                  src={selectedImage}
                  alt={f.label}
                  className={`filter-thumb-img ${f.class}`}
                />
              ) : (
                <div className="filter-thumb-placeholder">{f.label}</div>
              )}
              <span className="filter-thumb-label">{f.label}</span>
            </button>
          ))}
        </div>

        {/* Flecha derecha */}
        <button className="carousel-arrow right" onClick={next}>
          ▶
        </button>
      </div>
    </div>
  );
};

export default FilterThumbnails;
