import React, { useState } from "react";
import { Card, CardBody } from "@heroui/react";

import "./Style/editorCanvas.css";
import FilterThumbnails from "./extra/FilterThumbnails";
import FormatSelector from "./extra/FormatSelector";
import AdjustSliders from "./extra/AdjustSlider";

interface EditorControlsProps {
  selectedImage: string;
  filter: string;
  setFilter: (filter: string) => void;
  adjustments: {
    brillo: number;
    contraste: number;
    saturacion: number;
    intensidad: number;
  };
  setAdjustments: (adj: any) => void;
}

const EditorControls: React.FC<EditorControlsProps> = ({
  selectedImage,
  filter,
  setFilter,
  adjustments,
  setAdjustments,
}) => {
  const [selectedFormat, setSelectedFormat] = useState<string>("PNG");
  
  return (
    <div className="editor-controls w-72 p-4 space-y-6 bg-content2 border-l border-divider rounded-md">
      {/* Miniaturas de filtros */}
      <FilterThumbnails
        selectedImage={selectedImage}
        activeFilter={filter}
        setActiveFilter={setFilter}
      />

      {/* Sliders de ajustes */}
      <AdjustSliders
        adjustments={adjustments}
        setAdjustments={setAdjustments}
      />

      {/* Formatos */}
      <div>
        <h3>Seleccione el formato</h3>
        <FormatSelector
              selectedFormat={selectedFormat}
              onChange={setSelectedFormat}
          />
           
      </div>
    </div>
  );
};

export default EditorControls;
